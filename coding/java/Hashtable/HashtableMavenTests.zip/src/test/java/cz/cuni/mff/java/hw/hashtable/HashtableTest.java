package cz.cuni.mff.java.hw.hashtable;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.HashSet;

import static org.junit.jupiter.api.Assertions.*;

class HashtableTest {

    private Hashtable<Integer, String> hashtable;

    @BeforeEach
    void setUp() {
        hashtable = new Hashtable<>(5);
    }

    @Test
    void addSingleEntry() {
        hashtable.set(1, "one");
        assertEquals("one", hashtable.get(1));
    }

    @Test
    void overrideExistingEntry() {
        hashtable.set(1, "one");
        assertEquals("one", hashtable.get(1));

        hashtable.set(1, "uno"); // override existing one
        assertEquals("uno", hashtable.get(1));
    }

    @Test
    void setMultipleEntries() {
        hashtable.set(1, "one");
        hashtable.set(2, "two");
        hashtable.set(3, "three");

        assertEquals("one", hashtable.get(1));
        assertEquals("two", hashtable.get(2));
        assertEquals("three", hashtable.get(3));
    }

    @Test
    void handleSetNullKey() {
        assertThrows(IllegalArgumentException.class, () -> hashtable.set(null, "nullValue"));
    }

    @Test
    void handleSetNullValue() {
        assertThrows(IllegalArgumentException.class, () -> hashtable.set(1, null));
    }

    @Test
    void expansionOfTable() {
        for (int i = 1; i <= 10; i++) {
            hashtable.set(i, "value" + i);
        }

        for (int i = 1; i <= 10; i++) {
            assertEquals("value" + i, hashtable.get(i));
        }
    }

    @Test
    void setEntriesWithCollisions() {
        // Hash collision scenario: forcing keys to collide by implementing custom hashCode in Entry
        hashtable.set(1, "one");
        hashtable.set(6, "six"); // Collides with 1 due to small capacity (index = hash % 5)

        assertEquals("one", hashtable.get(1));
        assertEquals("six", hashtable.get(6));
    }

    @Test
    void getNonExistentKey() {
        hashtable.set(1, "one");
        assertNull(hashtable.get(99)); // Key 99 does not exist
    }

    @Test
    void iteratorTest() {
        hashtable.set(1, "one");
        hashtable.set(2, "two");
        hashtable.set(3, "three");

        var iterator = hashtable.iterator();
        var keys = new HashSet<Integer>();

        while (iterator.hasNext()) {
            keys.add(iterator.next());
        }

        assertEquals(3, keys.size());
        assertTrue(keys.contains(1));
        assertTrue(keys.contains(2));
        assertTrue(keys.contains(3));
    }

    @Test
    void iteratorEmptyTable() {
        var iterator = hashtable.iterator();
        assertFalse(iterator::hasNext);
    }

    @Test
    void iteratorOutOfBounds() {
        hashtable.set(1, "one");
        var iterator = hashtable.iterator();

        iterator.next();
        assertThrows(IndexOutOfBoundsException.class, iterator::next);
    }

    @Test
    void tableRehashing() {
        hashtable.set(1, "one");
        hashtable.set(2, "two");
        hashtable.set(3, "three");
        hashtable.set(4, "four");
        hashtable.set(5, "five");
        hashtable.set(6, "six"); // should rehash and add sixth

        assertEquals("one", hashtable.get(1));
        assertEquals("two", hashtable.get(2));
        assertEquals("three", hashtable.get(3));
        assertEquals("four", hashtable.get(4));
        assertEquals("five", hashtable.get(5));
        assertEquals("six", hashtable.get(6));
    }

    @Test
    void forEachValue() {
        StringBuilder output = new StringBuilder();
        hashtable.set(1, "one");
        hashtable.set(2, "two");
        hashtable.set(3, "three");

        hashtable.forEachValue(output::append);
        assertEquals("onetwothree", output.toString());
    }

    @Test
    void entityEquals() {
        Hashtable.Entry<String, Integer> nini21a = new Hashtable.Entry<>("nini", 21);
        Hashtable.Entry<String, Integer> nini21b = new Hashtable.Entry<>("nini", 21);
        Hashtable.Entry<String, Integer> nini21c = new Hashtable.Entry<>("nini", 21);
        Hashtable.Entry<String, Integer> jirc21 = new Hashtable.Entry<>("jirc", 21);
        Hashtable.Entry<String, Integer> jirc22 = new Hashtable.Entry<>("jirc", 22);

        assertFalse(nini21a.equals(null)); // object with null
        assertTrue(nini21a.equals(nini21a)); // reflexivity
        assertTrue(!(nini21a.equals(nini21b) && nini21b.equals(nini21c)) || (nini21a.equals(nini21c))); // transitivity
        assertTrue(nini21a.equals(nini21b)); // same fields
        assertFalse(nini21a.equals(jirc21)); // different key
        assertFalse(jirc22.equals(jirc21)); // different value
        assertFalse(nini21a.equals(jirc22)); // both different
    }
}
